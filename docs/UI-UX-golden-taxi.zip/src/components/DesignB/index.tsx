import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ArrowRight, ChevronLeft, Minus } from 'lucide-react';
import { MapPlaceholder } from '../shared/MapPlaceholder';
import { mockVehicles, mockDrivers, mockHistory } from '../shared/mockData';
import { useScreenInit } from '../../useScreenInit';
type Screen = 'home' | 'vehicle' | 'driver' | 'tracking' | 'profile';
export function DesignB() {
  const screenInit = useScreenInit();
  const [currentScreen, setCurrentScreen] = useState<Screen>(
    screenInit.screen || 'home'
  );
  const [selectedVehicle, setSelectedVehicle] = useState(mockVehicles[0].id);
  const [selectedDriver, setSelectedDriver] = useState(mockDrivers[0].id);
  const renderScreen = () => {
    switch (currentScreen) {
      case 'home':
        return <HomeScreen onNext={() => setCurrentScreen('vehicle')} />;
      case 'vehicle':
        return (
          <VehicleScreen
            selectedId={selectedVehicle}
            onSelect={setSelectedVehicle}
            onNext={() => setCurrentScreen('driver')}
            onBack={() => setCurrentScreen('home')} />);


      case 'driver':
        return (
          <DriverScreen
            selectedId={selectedDriver}
            onSelect={setSelectedDriver}
            onNext={() => setCurrentScreen('tracking')}
            onBack={() => setCurrentScreen('vehicle')} />);


      case 'tracking':
        return <TrackingScreen onFinish={() => setCurrentScreen('home')} />;
      case 'profile':
        return <ProfileScreen onBack={() => setCurrentScreen('home')} />;
    }
  };
  return (
    <div className="w-full h-full min-h-screen bg-black text-white font-sans relative overflow-hidden flex justify-center">
      <div className="w-full max-w-md h-full min-h-screen relative flex flex-col bg-black border-x border-[#111]">
        {/* Minimal Top Nav (Except Tracking) */}
        {currentScreen !== 'tracking' &&
        <div className="absolute top-0 w-full h-24 z-50 px-6 pt-12 flex justify-between items-center pointer-events-none">
            <div className="pointer-events-auto">
              {currentScreen !== 'home' ?
            <button
              onClick={() => setCurrentScreen('home')}
              className="text-white hover:text-[#d4af37] transition-colors">
              
                  <ChevronLeft size={28} strokeWidth={1} />
                </button> :

            <div className="w-7 h-7" />
            }
            </div>
            <button
            onClick={() =>
            setCurrentScreen(
              currentScreen === 'profile' ? 'home' : 'profile'
            )
            }
            className="pointer-events-auto text-[10px] uppercase tracking-[0.2em] text-[#888] hover:text-white transition-colors">
            
              {currentScreen === 'profile' ? 'Zavrieť' : 'Menu'}
            </button>
          </div>
        }

        {/* Main Content Area */}
        <div className="flex-1 relative overflow-hidden">
          <AnimatePresence mode="wait">
            <motion.div
              key={currentScreen}
              initial={{
                opacity: 0
              }}
              animate={{
                opacity: 1
              }}
              exit={{
                opacity: 0
              }}
              transition={{
                duration: 0.4,
                ease: 'easeInOut'
              }}
              className="absolute inset-0">
              
              {renderScreen()}
            </motion.div>
          </AnimatePresence>
        </div>
      </div>
    </div>);

}
// --- SCREENS ---
function HomeScreen({ onNext }: {onNext: () => void;}) {
  return (
    <div className="h-full relative flex flex-col px-8 pt-32 pb-12">
      <MapPlaceholder theme="stealth-luxury" className="opacity-40" />

      <div className="relative z-10 flex-1 flex flex-col">
        <motion.h1
          initial={{
            y: 10,
            opacity: 0
          }}
          animate={{
            y: 0,
            opacity: 1
          }}
          transition={{
            delay: 0.2
          }}
          className="text-5xl font-light tracking-tight mb-16 leading-tight">
          
          Kde
          <br />
          idete?
        </motion.h1>

        <div className="space-y-8 mt-auto">
          <div className="relative">
            <p className="text-[10px] uppercase tracking-[0.2em] text-[#666] mb-2">
              Z
            </p>
            <input
              type="text"
              defaultValue="Grand Hotel River Park"
              className="w-full bg-transparent border-b border-[#333] pb-4 text-xl font-light focus:outline-none focus:border-[#d4af37] transition-colors" />
            
          </div>

          <div className="relative">
            <p className="text-[10px] uppercase tracking-[0.2em] text-[#666] mb-2">
              Do
            </p>
            <input
              type="text"
              placeholder="Zadajte destináciu"
              defaultValue="Letisko M. R. Štefánika"
              className="w-full bg-transparent border-b border-[#333] pb-4 text-xl font-light focus:outline-none focus:border-[#d4af37] transition-colors" />
            
          </div>
        </div>

        <button
          onClick={onNext}
          className="mt-16 w-16 h-16 rounded-full border border-[#333] flex items-center justify-center self-end hover:border-[#d4af37] hover:text-[#d4af37] transition-all group">
          
          <ArrowRight
            size={24}
            strokeWidth={1}
            className="group-hover:translate-x-1 transition-transform" />
          
        </button>
      </div>
    </div>);

}
function VehicleScreen({ selectedId, onSelect, onNext }: any) {
  return (
    <div className="h-full relative flex flex-col px-8 pt-32 pb-12 bg-black">
      <h2 className="text-[10px] uppercase tracking-[0.2em] text-[#666] mb-12">
        Flotila
      </h2>

      <div className="flex-1 overflow-y-auto hide-scrollbar space-y-8">
        {mockVehicles.map((v) =>
        <div
          key={v.id}
          onClick={() => onSelect(v.id)}
          className="cursor-pointer group">
          
            <div className="flex items-end justify-between border-b border-[#222] pb-6 group-hover:border-[#d4af37] transition-colors">
              <div>
                <p
                className={`text-[10px] uppercase tracking-[0.2em] mb-2 transition-colors ${selectedId === v.id ? 'text-[#d4af37]' : 'text-[#444]'}`}>
                
                  {v.classLabel}
                </p>
                <h3
                className={`text-2xl font-light transition-colors ${selectedId === v.id ? 'text-white' : 'text-[#888]'}`}>
                
                  {v.name}
                </h3>
              </div>
              <div className="text-right">
                <p
                className={`text-xl font-light transition-colors ${selectedId === v.id ? 'text-white' : 'text-[#888]'}`}>
                
                  €{v.basePrice + v.pricePerKm * 15}
                </p>
              </div>
            </div>

            <AnimatePresence>
              {selectedId === v.id &&
            <motion.div
              initial={{
                height: 0,
                opacity: 0
              }}
              animate={{
                height: 'auto',
                opacity: 1
              }}
              exit={{
                height: 0,
                opacity: 0
              }}
              className="overflow-hidden">
              
                  <div className="pt-4 flex gap-6 text-[11px] text-[#666] uppercase tracking-wider">
                    <span>{v.capacity} Miesta</span>
                    {v.specs.slice(0, 2).map((s) =>
                <span key={s}>{s}</span>
                )}
                  </div>
                </motion.div>
            }
            </AnimatePresence>
          </div>
        )}
      </div>

      <button
        onClick={onNext}
        className="mt-8 w-full py-6 border border-[#333] text-[11px] uppercase tracking-[0.2em] hover:border-[#d4af37] hover:text-[#d4af37] transition-all">
        
        Pokračovať
      </button>
    </div>);

}
function DriverScreen({ selectedId, onSelect, onNext }: any) {
  return (
    <div className="h-full relative flex flex-col px-8 pt-32 pb-12 bg-black">
      <h2 className="text-[10px] uppercase tracking-[0.2em] text-[#666] mb-12">
        Vodič
      </h2>

      <div className="flex-1 overflow-y-auto hide-scrollbar space-y-6">
        {mockDrivers.map((d) =>
        <div
          key={d.id}
          onClick={() => onSelect(d.id)}
          className="cursor-pointer group flex items-center justify-between border-b border-[#222] pb-6 hover:border-[#d4af37] transition-colors">
          
            <div>
              <div className="flex items-center gap-3 mb-2">
                <h3
                className={`text-xl font-light transition-colors ${selectedId === d.id ? 'text-white' : 'text-[#888]'}`}>
                
                  {d.name}
                </h3>
                {d.isFavorite &&
              <div className="w-1.5 h-1.5 rounded-full bg-[#d4af37]" />
              }
              </div>
              <p className="text-[11px] text-[#666] tracking-wider">
                {d.rating} Hodnotenie • {d.languages.join(', ')}
              </p>
            </div>

            <div
            className={`w-6 h-6 rounded-full border flex items-center justify-center transition-colors ${selectedId === d.id ? 'border-[#d4af37] bg-[#d4af37]' : 'border-[#333]'}`}>
            
              {selectedId === d.id &&
            <div className="w-2 h-2 bg-black rounded-full" />
            }
            </div>
          </div>
        )}
      </div>

      <button
        onClick={onNext}
        className="mt-8 w-full py-6 bg-white text-black text-[11px] uppercase tracking-[0.2em] hover:bg-[#d4af37] transition-all font-medium">
        
        Objednať
      </button>
    </div>);

}
function TrackingScreen({ onFinish }: {onFinish: () => void;}) {
  const driver = mockDrivers[0];
  return (
    <div className="h-full relative flex flex-col bg-black">
      <MapPlaceholder theme="stealth-luxury" />

      <div className="absolute top-0 left-0 right-0 bg-gradient-to-b from-black to-transparent pt-14 px-8 pb-8 z-10">
        <div className="flex justify-between items-start">
          <div>
            <p className="text-[10px] uppercase tracking-[0.2em] text-[#d4af37] mb-2">
              Príchod
            </p>
            <h2 className="text-5xl font-light">
              4<span className="text-2xl text-[#666] ml-1">min</span>
            </h2>
          </div>
          <button
            onClick={onFinish}
            className="text-[10px] uppercase tracking-[0.2em] text-[#666] hover:text-white transition-colors">
            
            Zrušiť
          </button>
        </div>
      </div>

      <div className="mt-auto relative z-10 bg-black border-t border-[#222] p-8">
        <div className="flex justify-between items-center mb-8">
          <div>
            <h3 className="text-xl font-light mb-1">{driver.name}</h3>
            <p className="text-[11px] text-[#666] tracking-wider uppercase">
              BA-123-VIP
            </p>
          </div>
          <div className="text-right">
            <p className="text-xl font-light mb-1">
              1.2<span className="text-sm text-[#666] ml-1">km</span>
            </p>
            <p className="text-[11px] text-[#666] tracking-wider uppercase">
              Vzdialenosť
            </p>
          </div>
        </div>

        <div className="flex gap-4">
          <button className="flex-1 py-4 border border-[#333] text-[10px] uppercase tracking-[0.2em] hover:border-white transition-colors">
            Správa
          </button>
          <button className="flex-1 py-4 border border-[#333] text-[10px] uppercase tracking-[0.2em] hover:border-white transition-colors">
            Volať
          </button>
        </div>
      </div>
    </div>);

}
function ProfileScreen({ onBack }: {onBack: () => void;}) {
  return (
    <div className="h-full relative flex flex-col px-8 pt-32 pb-12 bg-black">
      <h2 className="text-[10px] uppercase tracking-[0.2em] text-[#666] mb-12">
        Profil
      </h2>

      <div className="mb-16">
        <h1 className="text-4xl font-light mb-2">Alexander K.</h1>
        <p className="text-[11px] text-[#d4af37] uppercase tracking-[0.2em]">
          Elite Member
        </p>
      </div>

      <div className="grid grid-cols-2 gap-8 mb-16 border-b border-[#222] pb-16">
        <div>
          <p className="text-[10px] uppercase tracking-[0.2em] text-[#666] mb-2">
            Jazdy
          </p>
          <p className="text-3xl font-light">42</p>
        </div>
        <div>
          <p className="text-[10px] uppercase tracking-[0.2em] text-[#666] mb-2">
            Hodnotenie
          </p>
          <p className="text-3xl font-light">5.0</p>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto hide-scrollbar">
        <h3 className="text-[10px] uppercase tracking-[0.2em] text-[#666] mb-6">
          História
        </h3>
        <div className="space-y-6">
          {mockHistory.map((h) =>
          <div
            key={h.id}
            className="flex justify-between items-center group cursor-pointer">
            
              <div>
                <p className="text-sm font-light mb-1 group-hover:text-[#d4af37] transition-colors">
                  {h.to}
                </p>
                <p className="text-[10px] text-[#666] uppercase tracking-wider">
                  {h.date}
                </p>
              </div>
              <p className="text-sm font-light text-[#888]">
                €{h.price.toFixed(2)}
              </p>
            </div>
          )}
        </div>
      </div>
    </div>);

}