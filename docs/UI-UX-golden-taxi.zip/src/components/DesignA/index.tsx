import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  MapPin,
  Navigation,
  Car,
  User,
  Star,
  Shield,
  Clock,
  ChevronRight,
  CheckCircle2,
  History,
  Map as MapIcon } from
'lucide-react';
import { MapPlaceholder } from '../shared/MapPlaceholder';
import {
  mockVehicles,
  mockDrivers,
  mockLocations,
  mockHistory } from
'../shared/mockData';
import { useScreenInit } from '../../useScreenInit';
type Screen = 'home' | 'vehicle' | 'driver' | 'tracking' | 'profile';
export function DesignA() {
  const screenInit = useScreenInit();
  const [currentScreen, setCurrentScreen] = useState<Screen>(
    screenInit.screen || 'home'
  );
  const [selectedVehicle, setSelectedVehicle] = useState(mockVehicles[0].id);
  const [selectedDriver, setSelectedDriver] = useState(mockDrivers[0].id);
  const renderScreen = () => {
    switch (currentScreen) {
      case 'home':
        return <HomeScreen onNext={() => setCurrentScreen('vehicle')} />;
      case 'vehicle':
        return (
          <VehicleScreen
            selectedId={selectedVehicle}
            onSelect={setSelectedVehicle}
            onNext={() => setCurrentScreen('driver')}
            onBack={() => setCurrentScreen('home')} />);


      case 'driver':
        return (
          <DriverScreen
            selectedId={selectedDriver}
            onSelect={setSelectedDriver}
            onNext={() => setCurrentScreen('tracking')}
            onBack={() => setCurrentScreen('vehicle')} />);


      case 'tracking':
        return <TrackingScreen onFinish={() => setCurrentScreen('home')} />;
      case 'profile':
        return <ProfileScreen />;
    }
  };
  return (
    <div className="w-full h-full min-h-screen bg-[#0a0a0a] text-[#f5f5f5] font-sans relative overflow-hidden flex justify-center">
      <div className="w-full max-w-md h-full min-h-screen relative flex flex-col bg-[#0a0a0a] shadow-2xl border-x border-[#1a1a1a]">
        {/* Main Content Area */}
        <div className="flex-1 relative overflow-hidden">
          <AnimatePresence mode="wait">
            <motion.div
              key={currentScreen}
              initial={{
                opacity: 0,
                x: 20
              }}
              animate={{
                opacity: 1,
                x: 0
              }}
              exit={{
                opacity: 0,
                x: -20
              }}
              transition={{
                duration: 0.3,
                ease: 'easeOut'
              }}
              className="absolute inset-0">
              
              {renderScreen()}
            </motion.div>
          </AnimatePresence>
        </div>

        {/* Bottom Tab Bar (Hidden in Tracking) */}
        {currentScreen !== 'tracking' &&
        <div className="h-20 bg-[#0a0a0a]/90 backdrop-blur-xl border-t border-[#2a2a2a] flex items-center justify-around px-6 pb-safe z-50 relative">
            <TabButton
            icon={<MapIcon />}
            label="Domov"
            active={
            currentScreen === 'home' ||
            currentScreen === 'vehicle' ||
            currentScreen === 'driver'
            }
            onClick={() => setCurrentScreen('home')} />
          
            <TabButton
            icon={<History />}
            label="História"
            active={false}
            onClick={() => {}} />
          
            <TabButton
            icon={<User />}
            label="Profil"
            active={currentScreen === 'profile'}
            onClick={() => setCurrentScreen('profile')} />
          
          </div>
        }
      </div>
    </div>);

}
function TabButton({
  icon,
  label,
  active,
  onClick





}: {icon: React.ReactNode;label: string;active: boolean;onClick: () => void;}) {
  return (
    <button
      onClick={onClick}
      className={`flex flex-col items-center gap-1 transition-colors ${active ? 'text-[#d4af37]' : 'text-[#666] hover:text-[#a0a0a0]'}`}>
      
      <div className="w-6 h-6">{icon}</div>
      <span className="text-[10px] font-medium tracking-wider uppercase">
        {label}
      </span>
    </button>);

}
// --- SCREENS ---
function HomeScreen({ onNext }: {onNext: () => void;}) {
  return (
    <div className="h-full relative flex flex-col">
      <MapPlaceholder theme="dark-opulence" />

      <div className="relative z-10 pt-16 px-6">
        <h1 className="text-3xl font-light tracking-wide text-white mb-2">
          Dobrý deň,{' '}
          <span className="font-semibold text-[#d4af37]">Alexander</span>
        </h1>
        <p className="text-[#a0a0a0] text-sm">Kam vás dnes odvezieme?</p>
      </div>

      <div className="mt-auto relative z-10 p-6 pb-8">
        <div className="bg-[#1a1a1a]/80 backdrop-blur-xl border border-[#2a2a2a] rounded-3xl p-5 shadow-2xl">
          <div className="flex items-center gap-4 mb-6">
            <div className="w-10 h-10 rounded-full bg-[#2a2a2a] flex items-center justify-center text-[#d4af37]">
              <MapPin size={20} />
            </div>
            <div className="flex-1 border-b border-[#333] pb-2">
              <p className="text-xs text-[#a0a0a0] uppercase tracking-wider mb-1">
                Vyzdvihnutie
              </p>
              <p className="text-white font-medium">Grand Hotel River Park</p>
            </div>
          </div>

          <div className="flex items-center gap-4 mb-6">
            <div className="w-10 h-10 rounded-full bg-[#d4af37]/20 flex items-center justify-center text-[#d4af37]">
              <Navigation size={20} />
            </div>
            <div className="flex-1 border-b border-[#333] pb-2">
              <p className="text-xs text-[#a0a0a0] uppercase tracking-wider mb-1">
                Cieľ
              </p>
              <input
                type="text"
                placeholder="Zadajte cieľovú adresu..."
                className="bg-transparent w-full text-white font-medium placeholder:text-[#666] outline-none"
                defaultValue="Letisko M. R. Štefánika" />
              
            </div>
          </div>

          <button
            onClick={onNext}
            className="w-full bg-gradient-to-r from-[#d4af37] to-[#b5952f] text-black font-semibold py-4 rounded-2xl shadow-[0_0_20px_rgba(212,175,55,0.3)] hover:shadow-[0_0_30px_rgba(212,175,55,0.5)] transition-all flex items-center justify-center gap-2">
            
            Pokračovať na výber vozidla
            <ChevronRight size={20} />
          </button>
        </div>
      </div>
    </div>);

}
function VehicleScreen({ selectedId, onSelect, onNext, onBack }: any) {
  return (
    <div className="h-full relative flex flex-col bg-[#0a0a0a]">
      <div className="pt-14 px-6 pb-4 flex items-center gap-4 relative z-10">
        <button
          onClick={onBack}
          className="w-10 h-10 rounded-full bg-[#1a1a1a] border border-[#2a2a2a] flex items-center justify-center text-white">
          
          <ChevronRight size={20} className="rotate-180" />
        </button>
        <h2 className="text-xl font-medium">Výber vozidla</h2>
      </div>

      <div className="flex-1 overflow-hidden flex flex-col justify-center relative z-10">
        <div className="flex overflow-x-auto snap-x snap-mandatory px-6 pb-8 gap-6 hide-scrollbar">
          {mockVehicles.map((v) =>
          <div
            key={v.id}
            onClick={() => onSelect(v.id)}
            className={`min-w-[85%] snap-center relative rounded-3xl overflow-hidden transition-all duration-300 cursor-pointer border-2 ${selectedId === v.id ? 'border-[#d4af37] shadow-[0_0_30px_rgba(212,175,55,0.15)]' : 'border-[#2a2a2a] opacity-60 scale-95'}`}>
            
              <div className="h-64 relative">
                <img
                src={v.imageUrl}
                alt={v.name}
                className="w-full h-full object-cover" />
              
                <div className="absolute inset-0 bg-gradient-to-t from-[#0a0a0a] via-[#0a0a0a]/40 to-transparent" />

                {selectedId === v.id &&
              <div className="absolute top-4 right-4 w-8 h-8 bg-[#d4af37] rounded-full flex items-center justify-center text-black">
                    <CheckCircle2 size={20} />
                  </div>
              }

                <div className="absolute bottom-4 left-4 right-4">
                  <p className="text-[#d4af37] text-xs font-bold tracking-widest uppercase mb-1">
                    {v.classLabel}
                  </p>
                  <h3 className="text-2xl font-light text-white">{v.name}</h3>
                </div>
              </div>

              <div className="bg-[#1a1a1a] p-5">
                <div className="flex justify-between items-center mb-4">
                  <div className="flex items-center gap-2 text-[#a0a0a0] text-sm">
                    <User size={16} /> {v.capacity} miesta
                  </div>
                  <div className="text-right">
                    <p className="text-sm text-[#a0a0a0]">Odhad</p>
                    <p className="text-xl font-semibold text-white">
                      €{v.basePrice + v.pricePerKm * 15}
                    </p>
                  </div>
                </div>

                <div className="flex flex-wrap gap-2">
                  {v.specs.map((spec) =>
                <span
                  key={spec}
                  className="text-[10px] uppercase tracking-wider px-3 py-1.5 rounded-full border border-[#333] text-[#a0a0a0]">
                  
                      {spec}
                    </span>
                )}
                </div>
              </div>
            </div>
          )}
        </div>
      </div>

      <div className="p-6 relative z-10 bg-gradient-to-t from-[#0a0a0a] via-[#0a0a0a] to-transparent">
        <button
          onClick={onNext}
          className="w-full bg-[#d4af37] text-black font-semibold py-4 rounded-2xl shadow-[0_0_20px_rgba(212,175,55,0.3)] hover:shadow-[0_0_30px_rgba(212,175,55,0.5)] transition-all">
          
          Vybrať vodiča
        </button>
      </div>
    </div>);

}
function DriverScreen({ selectedId, onSelect, onNext, onBack }: any) {
  return (
    <div className="h-full relative flex flex-col bg-[#0a0a0a]">
      <div className="pt-14 px-6 pb-4 flex items-center gap-4">
        <button
          onClick={onBack}
          className="w-10 h-10 rounded-full bg-[#1a1a1a] border border-[#2a2a2a] flex items-center justify-center text-white">
          
          <ChevronRight size={20} className="rotate-180" />
        </button>
        <h2 className="text-xl font-medium">Váš osobný vodič</h2>
      </div>

      <div className="flex-1 overflow-y-auto px-6 pb-24 hide-scrollbar">
        <div className="grid gap-4">
          {mockDrivers.map((d) =>
          <div
            key={d.id}
            onClick={() => onSelect(d.id)}
            className={`p-4 rounded-2xl border transition-all cursor-pointer flex gap-4 items-center ${selectedId === d.id ? 'bg-[#1a1a1a] border-[#d4af37]' : 'bg-[#0f0f0f] border-[#2a2a2a] hover:border-[#444]'}`}>
            
              <div className="relative">
                <img
                src={d.photoUrl}
                alt={d.name}
                className="w-16 h-16 rounded-full object-cover border-2 border-[#2a2a2a]" />
              
                {d.isFavorite &&
              <div className="absolute -bottom-1 -right-1 w-6 h-6 bg-[#d4af37] rounded-full flex items-center justify-center text-black border-2 border-[#1a1a1a]">
                    <Star size={12} fill="currentColor" />
                  </div>
              }
              </div>

              <div className="flex-1">
                <div className="flex justify-between items-start mb-1">
                  <h3 className="font-medium text-lg">{d.name}</h3>
                  <div className="flex items-center gap-1 text-[#d4af37] bg-[#d4af37]/10 px-2 py-0.5 rounded-full text-xs font-semibold">
                    <Star size={12} fill="currentColor" />
                    {d.rating}
                  </div>
                </div>

                <p className="text-xs text-[#a0a0a0] mb-2">
                  {d.totalRides} prémiových jázd
                </p>

                <div className="flex flex-wrap gap-1.5">
                  {d.badges.map((b) =>
                <span
                  key={b}
                  className="text-[9px] uppercase tracking-wider px-2 py-1 rounded bg-[#2a2a2a] text-[#d4af37] flex items-center gap-1">
                  
                      <Shield size={10} /> {b}
                    </span>
                )}
                </div>
              </div>

              <div
              className={`w-6 h-6 rounded-full border flex items-center justify-center ${selectedId === d.id ? 'border-[#d4af37] bg-[#d4af37] text-black' : 'border-[#444] text-transparent'}`}>
              
                <CheckCircle2 size={16} />
              </div>
            </div>
          )}
        </div>
      </div>

      <div className="absolute bottom-0 left-0 right-0 p-6 bg-gradient-to-t from-[#0a0a0a] via-[#0a0a0a] to-transparent">
        <button
          onClick={onNext}
          className="w-full bg-[#d4af37] text-black font-semibold py-4 rounded-2xl shadow-[0_0_20px_rgba(212,175,55,0.3)] hover:shadow-[0_0_30px_rgba(212,175,55,0.5)] transition-all">
          
          Potvrdiť a objednať
        </button>
      </div>
    </div>);

}
function TrackingScreen({ onFinish }: {onFinish: () => void;}) {
  const driver = mockDrivers[0];
  const vehicle = mockVehicles[0];
  return (
    <div className="h-full relative flex flex-col">
      <MapPlaceholder theme="dark-opulence" />

      <div className="absolute top-14 left-6 right-6 flex justify-between items-center z-10">
        <div className="bg-[#1a1a1a]/80 backdrop-blur-md border border-[#2a2a2a] px-4 py-2 rounded-full flex items-center gap-2">
          <div className="w-2 h-2 bg-[#d4af37] rounded-full animate-pulse" />
          <span className="text-sm font-medium">Vodič je na ceste</span>
        </div>
        <button
          onClick={onFinish}
          className="w-10 h-10 rounded-full bg-[#1a1a1a]/80 backdrop-blur-md border border-[#2a2a2a] flex items-center justify-center text-white">
          
          <span className="text-xs font-bold">X</span>
        </button>
      </div>

      <div className="mt-auto relative z-10 p-6 pb-12">
        <div className="bg-[#1a1a1a]/90 backdrop-blur-xl border border-[#2a2a2a] rounded-3xl p-6 shadow-2xl">
          <div className="flex justify-between items-end mb-6 border-b border-[#333] pb-6">
            <div>
              <p className="text-sm text-[#a0a0a0] mb-1">Príchod za</p>
              <h2 className="text-4xl font-light text-white">
                4 <span className="text-xl text-[#d4af37]">min</span>
              </h2>
            </div>
            <div className="text-right">
              <p className="text-sm text-[#a0a0a0] mb-1">Vzdialenosť</p>
              <p className="text-xl font-medium">1.2 km</p>
            </div>
          </div>

          <div className="flex items-center gap-4 mb-6">
            <img
              src={driver.photoUrl}
              alt={driver.name}
              className="w-14 h-14 rounded-full object-cover border-2 border-[#d4af37]" />
            
            <div className="flex-1">
              <h3 className="font-medium text-lg text-white">{driver.name}</h3>
              <div className="flex items-center gap-2 text-sm text-[#a0a0a0]">
                <Star
                  size={14}
                  className="text-[#d4af37]"
                  fill="currentColor" />
                
                {driver.rating} • {vehicle.name}
              </div>
            </div>
            <div className="text-right">
              <div className="bg-[#2a2a2a] px-3 py-1 rounded-lg text-white font-mono text-lg tracking-wider border border-[#333]">
                BA-123-VIP
              </div>
            </div>
          </div>

          <div className="flex gap-3">
            <button className="flex-1 bg-[#2a2a2a] hover:bg-[#333] text-white py-3 rounded-xl font-medium transition-colors border border-[#333]">
              Kontaktovať
            </button>
            <button className="flex-1 bg-[#d4af37]/10 hover:bg-[#d4af37]/20 text-[#d4af37] py-3 rounded-xl font-medium transition-colors border border-[#d4af37]/30">
              Zdieľať jazdu
            </button>
          </div>
        </div>
      </div>
    </div>);

}
function ProfileScreen() {
  return (
    <div className="h-full relative flex flex-col bg-[#0a0a0a]">
      <div className="pt-16 px-6 pb-6 border-b border-[#1a1a1a]">
        <div className="flex items-center gap-6">
          <div className="w-20 h-20 rounded-full bg-gradient-to-br from-[#d4af37] to-[#8a7222] p-0.5">
            <div className="w-full h-full bg-[#0a0a0a] rounded-full flex items-center justify-center text-2xl font-light text-[#d4af37]">
              AK
            </div>
          </div>
          <div>
            <h2 className="text-2xl font-light mb-1">Alexander K.</h2>
            <p className="text-[#d4af37] text-sm font-medium uppercase tracking-wider">
              VIP Člen
            </p>
          </div>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto px-6 py-6 hide-scrollbar">
        <div className="grid grid-cols-2 gap-4 mb-8">
          <div className="bg-[#1a1a1a] border border-[#2a2a2a] rounded-2xl p-4">
            <p className="text-[#a0a0a0] text-xs uppercase tracking-wider mb-2">
              Jazdy
            </p>
            <p className="text-3xl font-light text-white">42</p>
          </div>
          <div className="bg-[#1a1a1a] border border-[#2a2a2a] rounded-2xl p-4">
            <p className="text-[#a0a0a0] text-xs uppercase tracking-wider mb-2">
              Ušetrený čas
            </p>
            <p className="text-3xl font-light text-white">
              18<span className="text-lg text-[#d4af37]">h</span>
            </p>
          </div>
        </div>

        <h3 className="text-lg font-medium mb-4">Obľúbení vodiči</h3>
        <div className="flex gap-4 overflow-x-auto pb-4 hide-scrollbar">
          {mockDrivers.
          filter((d) => d.isFavorite).
          map((d) =>
          <div
            key={d.id}
            className="min-w-[120px] bg-[#1a1a1a] border border-[#2a2a2a] rounded-2xl p-4 flex flex-col items-center text-center">
            
                <img
              src={d.photoUrl}
              alt={d.name}
              className="w-12 h-12 rounded-full object-cover mb-3 border border-[#d4af37]" />
            
                <p className="font-medium text-sm mb-1">{d.name}</p>
                <div className="flex items-center gap-1 text-[#d4af37] text-xs">
                  <Star size={10} fill="currentColor" /> {d.rating}
                </div>
              </div>
          )}
        </div>

        <h3 className="text-lg font-medium mb-4 mt-4">Posledné jazdy</h3>
        <div className="space-y-3">
          {mockHistory.map((h) =>
          <div
            key={h.id}
            className="bg-[#1a1a1a] border border-[#2a2a2a] rounded-2xl p-4 flex items-center justify-between">
            
              <div className="flex items-center gap-4">
                <div className="w-10 h-10 rounded-full bg-[#2a2a2a] flex items-center justify-center text-[#a0a0a0]">
                  <Car size={18} />
                </div>
                <div>
                  <p className="font-medium text-sm">{h.to}</p>
                  <p className="text-xs text-[#a0a0a0]">{h.date}</p>
                </div>
              </div>
              <p className="font-medium text-[#d4af37]">
                €{h.price.toFixed(2)}
              </p>
            </div>
          )}
        </div>
      </div>
    </div>);

}