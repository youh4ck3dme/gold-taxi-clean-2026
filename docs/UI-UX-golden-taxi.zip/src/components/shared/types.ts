export interface Vehicle {
  id: string;
  name: string;
  classLabel: string;
  capacity: number;
  pricePerKm: number;
  basePrice: number;
  imageUrl: string;
  specs: string[];
}

export interface Driver {
  id: string;
  name: string;
  photoUrl: string;
  rating: number;
  totalRides: number;
  badges: string[];
  isFavorite: boolean;
  languages: string[];
  vehicleId: string;
}

export interface Location {
  id: string;
  name: string;
  address: string;
  type: 'airport' | 'hotel' | 'office' | 'home' | 'recent';
}

export interface RideHistory {
  id: string;
  date: string;
  driverId: string;
  vehicleId: string;
  from: string;
  to: string;
  price: number;
  status: 'completed' | 'cancelled';
}