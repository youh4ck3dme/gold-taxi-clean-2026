import { Vehicle, Driver, Location, RideHistory } from './types';

export const mockVehicles: Vehicle[] = [
{
  id: 'v1',
  name: 'Mercedes S-Class',
  classLabel: 'First Class',
  capacity: 3,
  pricePerKm: 2.5,
  basePrice: 15,
  imageUrl:
  'https://images.unsplash.com/photo-1618843479313-40f8afb4b4d8?auto=format&fit=crop&q=80&w=800',
  specs: ['Masážne sedadlá', 'Wi-Fi', 'Voda zdarma']
},
{
  id: 'v2',
  name: 'BMW 7 Series',
  classLabel: 'Business VIP',
  capacity: 3,
  pricePerKm: 2.3,
  basePrice: 12,
  imageUrl:
  'https://images.unsplash.com/photo-1555353540-64fd8b01bfce?auto=format&fit=crop&q=80&w=800',
  specs: ['Panoramatická strecha', 'Tichý režim', 'Zásuvka 230V']
},
{
  id: 'v3',
  name: 'Tesla Model S',
  classLabel: 'Eco Premium',
  capacity: 3,
  pricePerKm: 2.0,
  basePrice: 10,
  imageUrl:
  'https://images.unsplash.com/photo-1617788138017-80ad40651399?auto=format&fit=crop&q=80&w=800',
  specs: ['Zero Emissions', 'Spotify Premium', 'HEPA filter']
},
{
  id: 'v4',
  name: 'Audi A8',
  classLabel: 'Executive',
  capacity: 3,
  pricePerKm: 2.4,
  basePrice: 14,
  imageUrl:
  'https://images.unsplash.com/photo-1603584173870-7f23fdae1b7a?auto=format&fit=crop&q=80&w=800',
  specs: ['Bang & Olufsen', 'Zatemnené okná', 'Denná tlač']
}];


export const mockDrivers: Driver[] = [
{
  id: 'd1',
  name: 'Alexander K.',
  photoUrl:
  'https://images.unsplash.com/photo-1560250097-0b93528c311a?auto=format&fit=crop&q=80&w=400',
  rating: 4.98,
  totalRides: 1240,
  badges: ['5★ Elite', 'VIP Certified'],
  isFavorite: true,
  languages: ['SK', 'EN', 'DE'],
  vehicleId: 'v1'
},
{
  id: 'd2',
  name: 'Martin V.',
  photoUrl:
  'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?auto=format&fit=crop&q=80&w=400',
  rating: 4.95,
  totalRides: 850,
  badges: ['Discreet Mode', '1000+ Rides'],
  isFavorite: false,
  languages: ['SK', 'EN'],
  vehicleId: 'v2'
},
{
  id: 'd3',
  name: 'Peter S.',
  photoUrl:
  'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?auto=format&fit=crop&q=80&w=400',
  rating: 4.89,
  totalRides: 420,
  badges: ['Eco Driver'],
  isFavorite: false,
  languages: ['SK', 'EN'],
  vehicleId: 'v3'
},
{
  id: 'd4',
  name: 'Jozef M.',
  photoUrl:
  'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&q=80&w=400',
  rating: 4.99,
  totalRides: 2100,
  badges: ['5★ Elite', 'VIP Certified', 'Legend'],
  isFavorite: true,
  languages: ['SK', 'EN', 'RU'],
  vehicleId: 'v4'
}];


export const mockLocations: Location[] = [
{
  id: 'l1',
  name: 'Letisko M. R. Štefánika',
  address: 'Ivanská cesta, Bratislava',
  type: 'airport'
},
{
  id: 'l2',
  name: 'Grand Hotel River Park',
  address: 'Dvořákovo nábrežie 6',
  type: 'hotel'
},
{
  id: 'l3',
  name: 'Sky Park Offices',
  address: 'Čulenova, Bratislava',
  type: 'office'
},
{ id: 'l4', name: 'Domov', address: 'Koliba, Bratislava', type: 'home' }];


export const mockHistory: RideHistory[] = [
{
  id: 'r1',
  date: 'Dnes, 09:30',
  driverId: 'd1',
  vehicleId: 'v1',
  from: 'Sky Park Offices',
  to: 'Letisko M. R. Štefánika',
  price: 35.5,
  status: 'completed'
},
{
  id: 'r2',
  date: 'Včera, 18:45',
  driverId: 'd4',
  vehicleId: 'v4',
  from: 'Grand Hotel River Park',
  to: 'Sky Park Offices',
  price: 18.0,
  status: 'completed'
}];