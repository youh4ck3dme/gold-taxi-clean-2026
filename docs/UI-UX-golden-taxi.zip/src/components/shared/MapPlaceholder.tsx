import React from 'react';
interface MapPlaceholderProps {
  className?: string;
  theme?: 'dark-opulence' | 'stealth-luxury';
}
export function MapPlaceholder({
  className = '',
  theme = 'dark-opulence'
}: MapPlaceholderProps) {
  const isOpulence = theme === 'dark-opulence';
  return (
    <div
      className={`absolute inset-0 overflow-hidden pointer-events-none ${className}`}>
      
      {/* Base background */}
      <div
        className={`absolute inset-0 ${isOpulence ? 'bg-[#0a0a0a]' : 'bg-black'}`} />
      

      {/* Grid / Dots pattern */}
      <svg
        className="absolute inset-0 w-full h-full opacity-20"
        xmlns="http://www.w3.org/2000/svg">
        
        <defs>
          <pattern
            id={`grid-${theme}`}
            width="40"
            height="40"
            patternUnits="userSpaceOnUse">
            
            {isOpulence ?
            <path
              d="M 40 0 L 0 0 0 40"
              fill="none"
              stroke="#d4af37"
              strokeWidth="0.5"
              opacity="0.3" /> :


            <circle cx="2" cy="2" r="1" fill="#333" />
            }
          </pattern>
        </defs>
        <rect width="100%" height="100%" fill={`url(#grid-${theme})`} />
      </svg>

      {/* Abstract roads */}
      <svg
        className="absolute inset-0 w-full h-full opacity-30"
        viewBox="0 0 400 800"
        preserveAspectRatio="xMidYMid slice"
        xmlns="http://www.w3.org/2000/svg">
        
        {isOpulence ?
        <>
            <path
            d="M-100,200 Q150,300 200,800"
            fill="none"
            stroke="#2a2a2a"
            strokeWidth="12"
            strokeLinecap="round" />
          
            <path
            d="M400,100 Q250,400 100,900"
            fill="none"
            stroke="#1a1a1a"
            strokeWidth="8"
            strokeLinecap="round" />
          
            <path
            d="M-50,500 Q200,450 450,600"
            fill="none"
            stroke="#d4af37"
            strokeWidth="2"
            strokeLinecap="round"
            opacity="0.5" />
          
          </> :

        <>
            <path
            d="M-100,200 L200,800"
            fill="none"
            stroke="#222"
            strokeWidth="2" />
          
            <path
            d="M400,100 L100,900"
            fill="none"
            stroke="#222"
            strokeWidth="2" />
          
            <path
            d="M-50,500 L450,600"
            fill="none"
            stroke="#d4af37"
            strokeWidth="1"
            opacity="0.5" />
          
          </>
        }
      </svg>

      {/* Vignette / Gradient overlay */}
      {isOpulence &&
      <div className="absolute inset-0 bg-gradient-to-t from-[#0a0a0a] via-transparent to-[#0a0a0a] opacity-80" />
      }
      {!isOpulence &&
      <div className="absolute inset-0 bg-gradient-to-b from-black via-transparent to-black opacity-90" />
      }
    </div>);

}