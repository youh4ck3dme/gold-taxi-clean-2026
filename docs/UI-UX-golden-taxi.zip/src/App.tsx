import React, { useState } from 'react';
import { DesignA } from './components/DesignA';
import { DesignB } from './components/DesignB';
import { useScreenInit } from './useScreenInit';
export function App() {
  const screenInit = useScreenInit();
  const [design, setDesign] = useState<'A' | 'B'>(screenInit.design || 'A');
  return (
    <div className="w-full min-h-screen bg-[#050505] relative">
      {/* Switcher UI - Fixed outside the mobile frame */}
      <div className="fixed top-4 left-1/2 -translate-x-1/2 z-[100] bg-[#111] border border-[#333] rounded-full p-1 flex shadow-2xl backdrop-blur-md">
        <button
          onClick={() => setDesign('A')}
          className={`px-6 py-2 rounded-full text-xs font-medium tracking-wide transition-all ${design === 'A' ? 'bg-[#d4af37] text-black shadow-[0_0_15px_rgba(212,175,55,0.3)]' : 'text-[#888] hover:text-white'}`}>
          
          Dark Opulence
        </button>
        <button
          onClick={() => setDesign('B')}
          className={`px-6 py-2 rounded-full text-xs font-medium tracking-wide transition-all ${design === 'B' ? 'bg-white text-black shadow-[0_0_15px_rgba(255,255,255,0.3)]' : 'text-[#888] hover:text-white'}`}>
          
          Stealth Luxury
        </button>
      </div>

      {/* Render selected design */}
      {design === 'A' ? <DesignA /> : <DesignB />}
    </div>);

}