export const manifest = {
  screens: {
    scr_rchlux: { name: "Dark Opulence - Home", route: "/", state: { "design": "A", "screen": "home" }, position: { "x": 160, "y": 220 } },
    scr_0fbujn: { name: "Dark Opulence - Vehicle Select", route: "/", state: { "design": "A", "screen": "vehicle" }, position: { "x": 1560, "y": 220 } },
    scr_d812g2: { name: "Dark Opulence - Driver Select", route: "/", state: { "design": "A", "screen": "driver" }, position: { "x": 2960, "y": 220 } },
    scr_k29vav: { name: "Dark Opulence - Tracking", route: "/", state: { "design": "A", "screen": "tracking" }, position: { "x": 4360, "y": 220 } },
    scr_2xkgi8: { name: "Dark Opulence - Profile", route: "/", state: { "design": "A", "screen": "profile" }, position: { "x": 5760, "y": 220 } },
    scr_o9fuba: { name: "Stealth Luxury - Home", route: "/", state: { "design": "B", "screen": "home" }, position: { "x": 160, "y": 2200 } },
    scr_s8rspn: { name: "Stealth Luxury - Vehicle Select", route: "/", state: { "design": "B", "screen": "vehicle" }, position: { "x": 1560, "y": 2200 } },
    scr_0qoqqe: { name: "Stealth Luxury - Driver Select", route: "/", state: { "design": "B", "screen": "driver" }, position: { "x": 2960, "y": 2200 } },
    scr_5rlftx: { name: "Stealth Luxury - Tracking", route: "/", state: { "design": "B", "screen": "tracking" }, position: { "x": 4360, "y": 2200 } },
    scr_4ngtz7: { name: "Stealth Luxury - Profile", route: "/", state: { "design": "B", "screen": "profile" }, position: { "x": 5760, "y": 2200 } }
  },
  sections: {
    sec_9v2esf: { name: "Dark Opulence", x: 0, y: 0, width: 7120, height: 1180 },
    sec_7qsoww: { name: "Stealth Luxury", x: 0, y: 1980, width: 7120, height: 1180 }
  },
  layers: [
  { kind: "section", id: "sec_9v2esf", children: [
    { kind: "screen", id: "scr_rchlux" },
    { kind: "screen", id: "scr_0fbujn" },
    { kind: "screen", id: "scr_d812g2" },
    { kind: "screen", id: "scr_k29vav" },
    { kind: "screen", id: "scr_2xkgi8" }]
  },
  { kind: "section", id: "sec_7qsoww", children: [
    { kind: "screen", id: "scr_o9fuba" },
    { kind: "screen", id: "scr_s8rspn" },
    { kind: "screen", id: "scr_0qoqqe" },
    { kind: "screen", id: "scr_5rlftx" },
    { kind: "screen", id: "scr_4ngtz7" }]
  }]

};