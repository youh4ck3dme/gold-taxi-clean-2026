export const manifest = {
  screens: {
    scr_hpecct: { name: "Anime Taxi - Landing", route: "/", state: { "isBooking": false } },
    scr_cz2ah0: { name: "Anime Taxi - Booking Flow", route: "/", state: { "isBooking": true } }
  },
  sections: {
    sec_9v2esf: { name: "Dark Opulence", x: 0, y: 0, width: 7120, height: 1180 },
    sec_7qsoww: { name: "Stealth Luxury", x: 0, y: 1980, width: 7120, height: 1180 }
  },
  layers: [
  { kind: "section", id: "sec_9v2esf", children: [
    { kind: "screen", id: "scr_rchlux" },
    { kind: "screen", id: "scr_0fbujn" },
    { kind: "screen", id: "scr_d812g2" },
    { kind: "screen", id: "scr_k29vav" },
    { kind: "screen", id: "scr_2xkgi8" }]
  },
  { kind: "section", id: "sec_7qsoww", children: [
    { kind: "screen", id: "scr_o9fuba" },
    { kind: "screen", id: "scr_s8rspn" },
    { kind: "screen", id: "scr_0qoqqe" },
    { kind: "screen", id: "scr_5rlftx" },
    { kind: "screen", id: "scr_4ngtz7" }]
  }]

};