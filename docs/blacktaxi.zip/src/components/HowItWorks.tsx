import React from 'react';
import { MapPin, Navigation, CheckCircle, User, Flag } from 'lucide-react';
const steps = [
{
  icon: MapPin,
  title: 'Choose Pickup',
  desc: 'Your location, detected'
},
{
  icon: Navigation,
  title: 'Choose Destination',
  desc: 'Where to next?'
},
{
  icon: CheckCircle,
  title: 'Confirm Ride',
  desc: 'Review and book'
},
{
  icon: User,
  title: 'Track Driver',
  desc: 'Real-time updates'
},
{
  icon: Flag,
  title: 'Complete Ride',
  desc: 'Arrive in silence'
}];

export function HowItWorks() {
  return (
    <section className="relative z-10 py-24 px-8 max-w-7xl mx-auto text-center">
      <h2 className="font-sans text-[11px] uppercase tracking-[0.4em] text-[#D4AF37] mb-4">
        HOW IT WORKS
      </h2>
      <div className="w-12 h-[1px] bg-[#D4AF37] mx-auto mb-20" />

      <div className="relative flex flex-col md:flex-row items-start justify-between gap-12">
        {/* Connection Line */}
        <div className="hidden md:block absolute top-12 left-0 right-0 h-[1px] border-t border-dashed border-[#D4AF37]/30 z-0" />

        {steps.map((s, i) =>
        <div
          key={i}
          className="relative z-10 flex flex-col items-center flex-1">
          
            <div className="w-24 h-24 rounded-full border border-[#D4AF37] flex items-center justify-center bg-black/60 backdrop-blur-md mb-6 gold-glow">
              <s.icon className="text-[#D4AF37] w-8 h-8" />
            </div>
            <div className="text-[#D4AF37] font-serif text-lg mb-2">
              0{i + 1}
            </div>
            <h3 className="font-sans text-sm font-bold text-white mb-2 uppercase tracking-widest">
              {s.title}
            </h3>
            <p className="text-xs text-white/40 max-w-[150px]">{s.desc}</p>
          </div>
        )}
      </div>
    </section>);

}