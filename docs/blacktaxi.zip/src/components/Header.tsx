import React, { useState } from 'react';
import { Crown, Menu, X } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
export function Header({ onBook }: {onBook: () => void;}) {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  return (
    <header className="fixed top-0 left-0 right-0 z-50 h-20 md:h-24 flex items-center justify-between px-6 md:px-16 bg-black/20 backdrop-blur-md border-b border-[#D4AF37]/10">
      <div className="flex items-center gap-3">
        <Crown className="text-[#D4AF37] w-6 h-6 md:w-8 md:h-8 animate-gold-shimmer" />
        <span className="font-serif text-xl md:text-2xl tracking-[0.2em] text-[#D4AF37] font-light">
          ANIME TAXI
        </span>
      </div>

      <nav className="hidden lg:flex items-center gap-12">
        {['Home', 'Services', 'Fleet', 'Business', 'About', 'Contact'].map(
          (item) =>
          <a
            key={item}
            href={`#${item.toLowerCase()}`}
            className="font-sans text-[11px] uppercase tracking-[0.25em] text-[#D4AF37]/60 hover:text-[#D4AF37] transition-colors">
            
              {item}
            </a>

        )}
      </nav>

      <div className="flex items-center gap-4">
        <button
          onClick={onBook}
          className="hidden sm:block px-6 md:px-8 py-2.5 md:py-3 border border-[#D4AF37] text-[#D4AF37] font-sans text-[10px] md:text-[11px] uppercase tracking-[0.2em] hover:bg-[#D4AF37] hover:text-black transition-all duration-500">
          
          Book a Ride
        </button>

        <button
          className="lg:hidden text-[#D4AF37] p-2"
          onClick={() => setIsMenuOpen(!isMenuOpen)}>
          
          {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
        </button>
      </div>

      {/* Mobile Menu */}
      <AnimatePresence>
        {isMenuOpen &&
        <motion.div
          initial={{
            opacity: 0,
            y: -20
          }}
          animate={{
            opacity: 1,
            y: 0
          }}
          exit={{
            opacity: 0,
            y: -20
          }}
          className="absolute top-full left-0 right-0 bg-black/95 backdrop-blur-xl border-b border-[#D4AF37]/20 p-8 flex flex-col gap-6 lg:hidden">
          
            {['Home', 'Services', 'Fleet', 'Business', 'About', 'Contact'].map(
            (item) =>
            <a
              key={item}
              href={`#${item.toLowerCase()}`}
              onClick={() => setIsMenuOpen(false)}
              className="font-sans text-sm uppercase tracking-[0.3em] text-[#D4AF37] border-b border-[#D4AF37]/10 pb-4">
              
                  {item}
                </a>

          )}
            <button
            onClick={() => {
              setIsMenuOpen(false);
              onBook();
            }}
            className="w-full py-4 bg-[#D4AF37] text-black font-sans text-xs uppercase tracking-[0.2em] font-bold">
            
              Book a Ride
            </button>
          </motion.div>
        }
      </AnimatePresence>
    </header>);

}