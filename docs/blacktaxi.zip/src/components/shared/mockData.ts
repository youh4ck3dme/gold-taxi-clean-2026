export const mockVehicles = [
{
  id: 'v1',
  name: 'Mercedes S-Class',
  classLabel: 'First Class',
  basePrice: 15,
  pricePerKm: 2.5,
  imageUrl:
  'https://images.unsplash.com/photo-1618843479313-40f8afb4b4d8?auto=format&fit=crop&q=80&w=800'
},
{
  id: 'v2',
  name: 'BMW 7 Series',
  classLabel: 'Business VIP',
  basePrice: 12,
  pricePerKm: 2.3,
  imageUrl:
  'https://images.unsplash.com/photo-1555353540-64fd8b01bfce?auto=format&fit=crop&q=80&w=800'
},
{
  id: 'v3',
  name: 'Tesla Model S',
  classLabel: 'Eco Premium',
  basePrice: 10,
  pricePerKm: 2.0,
  imageUrl:
  'https://images.unsplash.com/photo-1617788138017-80ad40651399?auto=format&fit=crop&q=80&w=800'
}];


export const mockDrivers = [
{
  id: 'd1',
  name: 'Alexander K.',
  photoUrl:
  'https://images.unsplash.com/photo-1560250097-0b93528c311a?auto=format&fit=crop&q=80&w=400',
  rating: 4.98,
  badges: ['5★ Elite', 'VIP Certified']
},
{
  id: 'd2',
  name: 'Martin V.',
  photoUrl:
  'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?auto=format&fit=crop&q=80&w=400',
  rating: 4.95,
  badges: ['Discreet Mode']
}];


export const mockLocations = [
{
  id: 'l1',
  name: 'Letisko M. R. Štefánika',
  address: 'Ivanská cesta, Bratislava'
},
{ id: 'l2', name: 'Grand Hotel River Park', address: 'Dvořákovo nábrežie 6' },
{ id: 'l3', name: 'Sky Park Offices', address: 'Čulenova, Bratislava' }];


export const mockHistory = [
{ id: 'r1', date: 'Dnes, 09:30', to: 'Letisko M. R. Štefánika', price: 35.5 },
{ id: 'r2', date: 'Včera, 18:45', to: 'Sky Park Offices', price: 18.0 }];