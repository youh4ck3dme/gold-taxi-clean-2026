import React from 'react';
import {
  Zap,
  Map,
  DollarSign,
  Shield,
  Calendar,
  Clock,
  CreditCard,
  Headphones } from
'lucide-react';
const features = [
{
  icon: Zap,
  title: 'Instant Booking',
  desc: 'One tap to luxury'
},
{
  icon: Map,
  title: 'Live Tracking',
  desc: 'Real-time precision'
},
{
  icon: DollarSign,
  title: 'Clear Pricing',
  desc: 'No hidden fees'
},
{
  icon: Shield,
  title: 'Executive Rides',
  desc: 'Vetted professionals'
},
{
  icon: Calendar,
  title: 'Scheduled Rides',
  desc: 'Plan with confidence'
},
{
  icon: Clock,
  title: 'Fast & Efficient',
  desc: 'Optimized routing'
},
{
  icon: CreditCard,
  title: 'Secure Payments',
  desc: 'Encrypted transactions'
},
{
  icon: Headphones,
  title: 'Premium Support',
  desc: 'Always available'
}];

export function FeaturesStrip() {
  return (
    <section className="relative z-10 py-16 md:py-24 px-4 md:px-8 overflow-x-auto hide-scrollbar">
      <div className="flex gap-4 md:gap-6 min-w-max mx-auto max-w-7xl">
        {features.map((f, i) =>
        <div
          key={i}
          className="glass-panel p-6 w-64 gold-glow-hover transition-all duration-500 group cursor-pointer">
          
            <f.icon className="text-[#D4AF37] w-6 h-6 mb-4 group-hover:scale-110 transition-transform" />
            <h3 className="font-sans text-[13px] font-bold text-white mb-1 uppercase tracking-wider">
              {f.title}
            </h3>
            <p className="text-[11px] text-white/50 tracking-wide">{f.desc}</p>
          </div>
        )}
      </div>
    </section>);

}