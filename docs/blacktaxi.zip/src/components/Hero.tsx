import React from 'react';
import { motion } from 'framer-motion';
import { ArrowDown } from 'lucide-react';
export function Hero({ onBook }: {onBook: () => void;}) {
  return (
    <section className="relative min-h-screen flex flex-col items-center justify-center text-center px-6 py-24 md:py-0 z-10">
      <motion.div
        initial={{
          opacity: 0,
          y: 20
        }}
        animate={{
          opacity: 1,
          y: 0
        }}
        className="inline-flex items-center px-4 py-1 rounded-full border border-[#D4AF37]/30 bg-black/40 backdrop-blur-md mb-8 md:mb-12">
        
        <span className="text-[10px] uppercase tracking-[0.3em] text-[#D4AF37]">
          AMOLED LUXURY · 2027
        </span>
      </motion.div>

      <div className="relative w-full">
        {/* Subtle radial gold glow */}
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[300px] md:w-[600px] h-[150px] md:h-[300px] bg-[#D4AF37]/5 blur-[60px] md:blur-[120px] rounded-full pointer-events-none" />

        <h1 className="font-serif text-5xl sm:text-7xl md:text-[120px] leading-tight md:leading-none mb-6 md:mb-8 tracking-[0.1em]">
          <span className="block font-light text-white opacity-90">
            MOVE IN
          </span>
          <span className="block text-[#D4AF37] italic font-extralight">
            SILENCE.
          </span>
        </h1>
      </div>

      <p className="font-sans text-xs md:text-base text-white/50 tracking-[0.15em] mb-12 md:mb-16 max-w-xl px-4">
        Premium executive rides. Zero wait. Zero compromise.
      </p>

      <div className="grid grid-cols-2 md:flex md:flex-wrap items-center justify-center gap-8 md:gap-12 mb-16 md:mb-20 w-full max-w-2xl">
        {[
        {
          label: 'On-Time',
          value: '98%'
        },
        {
          label: 'Rides',
          value: '10K+'
        },
        {
          label: 'Support',
          value: '24/7'
        },
        {
          label: 'Rating',
          value: '4.9★'
        }].
        map((stat, i) =>
        <div
          key={stat.label}
          className="flex items-center justify-center md:justify-start gap-8 md:gap-12">
          
            <div className="text-center md:text-left">
              <div className="text-xl md:text-2xl font-serif text-[#D4AF37] mb-1">
                {stat.value}
              </div>
              <div className="text-[9px] md:text-[10px] uppercase tracking-widest text-white/40">
                {stat.label}
              </div>
            </div>
            {i % 2 === 0 && i < 3 &&
          <div className="hidden md:block h-8 w-[1px] bg-[#D4AF37]/20" />
          }
          </div>
        )}
      </div>

      <div className="flex flex-col sm:flex-row gap-4 md:gap-6 w-full sm:w-auto">
        <button
          onClick={onBook}
          className="w-full sm:w-auto px-12 py-4 md:py-5 bg-[#D4AF37] text-black font-sans text-[11px] md:text-xs uppercase tracking-[0.2em] font-bold hover:bg-[#FFD700] transition-all gold-glow">
          
          Book a Ride →
        </button>
        <button className="w-full sm:w-auto px-12 py-4 md:py-5 border border-[#D4AF37] text-[#D4AF37] font-sans text-[11px] md:text-xs uppercase tracking-[0.2em] hover:bg-[#D4AF37]/10 transition-all">
          Explore Fleet
        </button>
      </div>

      <motion.div
        animate={{
          y: [0, 10, 0]
        }}
        transition={{
          repeat: Infinity,
          duration: 2
        }}
        className="absolute bottom-12 left-1/2 -translate-x-1/2 text-[#D4AF37]">
        
        <ArrowDown strokeWidth={1} size={32} />
      </motion.div>
    </section>);

}