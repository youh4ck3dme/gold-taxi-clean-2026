import React from 'react';
import { Crown, Twitter, Instagram, Linkedin } from 'lucide-react';
export function Footer() {
  return (
    <footer className="relative z-10 py-12 px-8 border-t border-[#D4AF37]/20">
      <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-8">
        <div className="flex items-center gap-3">
          <Crown className="text-[#D4AF37] w-6 h-6" />
          <span className="font-serif text-lg tracking-[0.2em] text-[#D4AF37] font-light">
            ANIME TAXI
          </span>
        </div>

        <p className="text-[10px] uppercase tracking-[0.2em] text-white/30">
          © 2027 Anime Taxi. All rights reserved.
        </p>

        <div className="flex items-center gap-8">
          {[Twitter, Instagram, Linkedin].map((Icon, i) =>
          <a
            key={i}
            href="#"
            className="text-[#D4AF37] hover:text-[#FFD700] transition-colors">
            
              <Icon size={20} strokeWidth={1.5} />
            </a>
          )}
        </div>
      </div>
    </footer>);

}