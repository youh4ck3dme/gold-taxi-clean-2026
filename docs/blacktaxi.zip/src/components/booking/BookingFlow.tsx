import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  MapPin,
  Navigation,
  Car,
  User,
  Star,
  Shield,
  ChevronRight,
  CheckCircle2,
  History,
  Map as MapIcon,
  X } from
'lucide-react';
import {
  mockVehicles,
  mockDrivers,
  mockLocations,
  mockHistory } from
'../shared/mockData';
type Screen = 'home' | 'vehicle' | 'driver' | 'tracking' | 'profile';
export function BookingFlow({
  onBackToLanding


}: {onBackToLanding: () => void;}) {
  const [currentScreen, setCurrentScreen] = useState<Screen>('home');
  const [selectedVehicle, setSelectedVehicle] = useState(mockVehicles[0].id);
  const [selectedDriver, setSelectedDriver] = useState(mockDrivers[0].id);
  const renderScreen = () => {
    switch (currentScreen) {
      case 'home':
        return (
          <HomeScreen
            onNext={() => setCurrentScreen('vehicle')}
            onExit={onBackToLanding} />);


      case 'vehicle':
        return (
          <VehicleScreen
            selectedId={selectedVehicle}
            onSelect={setSelectedVehicle}
            onNext={() => setCurrentScreen('driver')}
            onBack={() => setCurrentScreen('home')} />);


      case 'driver':
        return (
          <DriverScreen
            selectedId={selectedDriver}
            onSelect={setSelectedDriver}
            onNext={() => setCurrentScreen('tracking')}
            onBack={() => setCurrentScreen('vehicle')} />);


      case 'tracking':
        return <TrackingScreen onFinish={() => setCurrentScreen('home')} />;
      case 'profile':
        return <ProfileScreen onBack={() => setCurrentScreen('home')} />;
    }
  };
  return (
    <div className="fixed inset-0 z-[100] bg-black flex justify-center items-center">
      <div className="w-full max-w-md h-full bg-[#0a0a0a] relative flex flex-col shadow-2xl md:border-x border-[#1a1a1a] overflow-hidden">
        <AnimatePresence mode="wait">
          <motion.div
            key={currentScreen}
            initial={{
              opacity: 0,
              x: 20
            }}
            animate={{
              opacity: 1,
              x: 0
            }}
            exit={{
              opacity: 0,
              x: -20
            }}
            transition={{
              duration: 0.3
            }}
            className="flex-1 h-full">
            
            {renderScreen()}
          </motion.div>
        </AnimatePresence>

        {currentScreen !== 'tracking' &&
        <div className="h-20 bg-[#0a0a0a]/90 backdrop-blur-xl border-t border-[#2a2a2a] flex items-center justify-around px-6 pb-safe">
            <button
            onClick={() => setCurrentScreen('home')}
            className={`flex flex-col items-center gap-1 ${currentScreen === 'home' ? 'text-[#d4af37]' : 'text-[#666]'}`}>
            
              <MapIcon size={20} />
              <span className="text-[10px] uppercase tracking-wider">
                Domov
              </span>
            </button>
            <button
            onClick={() => setCurrentScreen('profile')}
            className={`flex flex-col items-center gap-1 ${currentScreen === 'profile' ? 'text-[#d4af37]' : 'text-[#666]'}`}>
            
              <User size={20} />
              <span className="text-[10px] uppercase tracking-wider">
                Profil
              </span>
            </button>
          </div>
        }
      </div>
    </div>);

}
function HomeScreen({ onNext, onExit }: any) {
  return (
    <div className="h-full p-6 pt-16 flex flex-col">
      <div className="flex justify-between items-center mb-12">
        <h1 className="text-3xl font-light tracking-wide text-white">
          Kam vás dnes{' '}
          <span className="text-[#d4af37] font-semibold">odvezieme?</span>
        </h1>
        <button
          onClick={onExit}
          className="w-10 h-10 rounded-full bg-[#1a1a1a] border border-[#2a2a2a] flex items-center justify-center text-white">
          
          <X size={20} />
        </button>
      </div>

      <div className="bg-[#1a1a1a] border border-[#2a2a2a] rounded-3xl p-6 mb-8">
        <div className="flex items-center gap-4 mb-8">
          <div className="w-10 h-10 rounded-full bg-[#2a2a2a] flex items-center justify-center text-[#d4af37]">
            <MapPin size={20} />
          </div>
          <div className="flex-1 border-b border-[#333] pb-2">
            <p className="text-xs text-[#a0a0a0] uppercase tracking-wider mb-1">
              Vyzdvihnutie
            </p>
            <p className="text-white font-medium">Vaša poloha</p>
          </div>
        </div>

        <div className="flex items-center gap-4 mb-8">
          <div className="w-10 h-10 rounded-full bg-[#d4af37]/20 flex items-center justify-center text-[#d4af37]">
            <Navigation size={20} />
          </div>
          <div className="flex-1 border-b border-[#333] pb-2">
            <p className="text-xs text-[#a0a0a0] uppercase tracking-wider mb-1">
              Cieľ
            </p>
            <input
              type="text"
              placeholder="Zadajte cieľovú adresu..."
              className="bg-transparent w-full text-white font-medium placeholder:text-[#666] outline-none" />
            
          </div>
        </div>

        <button
          onClick={onNext}
          className="w-full bg-[#d4af37] text-black font-bold py-4 rounded-2xl shadow-[0_0_20px_rgba(212,175,55,0.3)]">
          
          Vybrať vozidlo
        </button>
      </div>

      <h3 className="text-sm font-medium text-[#a0a0a0] uppercase tracking-widest mb-4">
        Časté ciele
      </h3>
      <div className="space-y-3">
        {mockLocations.map((l) =>
        <button
          key={l.id}
          className="w-full bg-[#1a1a1a] border border-[#2a2a2a] rounded-2xl p-4 flex items-center gap-4 hover:border-[#d4af37] transition-colors text-left">
          
            <div className="w-8 h-8 rounded-full bg-[#2a2a2a] flex items-center justify-center text-[#d4af37]">
              <MapPin size={16} />
            </div>
            <div>
              <p className="font-medium text-white">{l.name}</p>
              <p className="text-xs text-[#a0a0a0]">{l.address}</p>
            </div>
          </button>
        )}
      </div>
    </div>);

}
function VehicleScreen({ selectedId, onSelect, onNext, onBack }: any) {
  return (
    <div className="h-full flex flex-col bg-[#0a0a0a]">
      <div className="pt-16 px-6 pb-4 flex items-center gap-4">
        <button
          onClick={onBack}
          className="w-10 h-10 rounded-full bg-[#1a1a1a] border border-[#2a2a2a] flex items-center justify-center text-white">
          
          <ChevronRight size={20} className="rotate-180" />
        </button>
        <h2 className="text-xl font-medium">Výber vozidla</h2>
      </div>

      <div className="flex-1 overflow-y-auto px-6 py-4 space-y-4">
        {mockVehicles.map((v) =>
        <div
          key={v.id}
          onClick={() => onSelect(v.id)}
          className={`p-4 rounded-3xl border transition-all cursor-pointer flex gap-4 items-center ${selectedId === v.id ? 'bg-[#1a1a1a] border-[#d4af37]' : 'bg-[#0f0f0f] border-[#2a2a2a]'}`}>
          
            <img
            src={v.imageUrl}
            alt={v.name}
            className="w-24 h-16 object-cover rounded-xl" />
          
            <div className="flex-1">
              <p className="text-[#d4af37] text-[10px] font-bold uppercase tracking-widest">
                {v.classLabel}
              </p>
              <h3 className="text-lg font-medium text-white">{v.name}</h3>
              <p className="text-xs text-[#a0a0a0]">
                €{v.basePrice + v.pricePerKm * 15} odhad
              </p>
            </div>
            <div
            className={`w-6 h-6 rounded-full border flex items-center justify-center ${selectedId === v.id ? 'border-[#d4af37] bg-[#d4af37] text-black' : 'border-[#444]'}`}>
            
              <CheckCircle2 size={16} />
            </div>
          </div>
        )}
      </div>

      <div className="p-6">
        <button
          onClick={onNext}
          className="w-full bg-[#d4af37] text-black font-bold py-4 rounded-2xl shadow-[0_0_20px_rgba(212,175,55,0.3)]">
          
          Pokračovať na výber vodiča
        </button>
      </div>
    </div>);

}
function DriverScreen({ selectedId, onSelect, onNext, onBack }: any) {
  return (
    <div className="h-full flex flex-col bg-[#0a0a0a]">
      <div className="pt-16 px-6 pb-4 flex items-center gap-4">
        <button
          onClick={onBack}
          className="w-10 h-10 rounded-full bg-[#1a1a1a] border border-[#2a2a2a] flex items-center justify-center text-white">
          
          <ChevronRight size={20} className="rotate-180" />
        </button>
        <h2 className="text-xl font-medium">Váš vodič</h2>
      </div>

      <div className="flex-1 overflow-y-auto px-6 py-4 space-y-4">
        {mockDrivers.map((d) =>
        <div
          key={d.id}
          onClick={() => onSelect(d.id)}
          className={`p-4 rounded-3xl border transition-all cursor-pointer flex gap-4 items-center ${selectedId === d.id ? 'bg-[#1a1a1a] border-[#d4af37]' : 'bg-[#0f0f0f] border-[#2a2a2a]'}`}>
          
            <img
            src={d.photoUrl}
            alt={d.name}
            className="w-16 h-16 rounded-full object-cover border border-[#2a2a2a]" />
          
            <div className="flex-1">
              <h3 className="font-medium text-white">{d.name}</h3>
              <div className="flex items-center gap-1 text-[#d4af37] text-xs">
                <Star size={12} fill="currentColor" /> {d.rating}
              </div>
              <p className="text-[10px] text-[#a0a0a0] uppercase tracking-widest mt-1">
                {d.badges[0]}
              </p>
            </div>
            <div
            className={`w-6 h-6 rounded-full border flex items-center justify-center ${selectedId === d.id ? 'border-[#d4af37] bg-[#d4af37] text-black' : 'border-[#444]'}`}>
            
              <CheckCircle2 size={16} />
            </div>
          </div>
        )}
      </div>

      <div className="p-6">
        <button
          onClick={onNext}
          className="w-full bg-[#d4af37] text-black font-bold py-4 rounded-2xl shadow-[0_0_20px_rgba(212,175,55,0.3)]">
          
          Potvrdiť jazdu
        </button>
      </div>
    </div>);

}
function TrackingScreen({ onFinish }: any) {
  return (
    <div className="h-full bg-black flex flex-col items-center justify-center p-6 text-center">
      <div className="w-24 h-24 rounded-full border-2 border-[#d4af37] flex items-center justify-center mb-8 animate-pulse">
        <Car size={48} className="text-[#d4af37]" />
      </div>
      <h2 className="text-3xl font-light text-white mb-4 tracking-wide">
        Vodič je na ceste
      </h2>
      <p className="text-[#a0a0a0] mb-12">
        Váš Mercedes S-Class dorazí o{' '}
        <span className="text-[#d4af37] font-bold">4 minúty</span>.
      </p>

      <div className="w-full bg-[#1a1a1a] border border-[#2a2a2a] rounded-3xl p-6 mb-8 flex items-center gap-4 text-left">
        <img
          src={mockDrivers[0].photoUrl}
          alt="Driver"
          className="w-16 h-16 rounded-full object-cover border border-[#d4af37]" />
        
        <div className="flex-1">
          <h3 className="font-medium text-white">{mockDrivers[0].name}</h3>
          <p className="text-xs text-[#a0a0a0]">BA-123-VIP</p>
        </div>
        <button className="w-12 h-12 rounded-full bg-[#2a2a2a] flex items-center justify-center text-[#d4af37]">
          <Shield size={20} />
        </button>
      </div>

      <button
        onClick={onFinish}
        className="w-full py-4 border border-[#d4af37] text-[#d4af37] font-bold rounded-2xl">
        
        Zrušiť jazdu
      </button>
    </div>);

}
function ProfileScreen({ onBack }: any) {
  return (
    <div className="h-full flex flex-col bg-[#0a0a0a]">
      <div className="pt-16 px-6 pb-6 border-b border-[#1a1a1a]">
        <div className="flex items-center gap-6">
          <div className="w-20 h-20 rounded-full bg-gradient-to-br from-[#d4af37] to-[#8a7222] p-0.5">
            <div className="w-full h-full bg-[#0a0a0a] rounded-full flex items-center justify-center text-2xl font-light text-[#d4af37]">
              AK
            </div>
          </div>
          <div>
            <h2 className="text-2xl font-light text-white">Alexander K.</h2>
            <p className="text-[#d4af37] text-xs font-bold uppercase tracking-widest">
              VIP Člen
            </p>
          </div>
        </div>
      </div>
      <div className="p-6">
        <h3 className="text-sm font-medium text-[#a0a0a0] uppercase tracking-widest mb-4">
          Posledné jazdy
        </h3>
        <div className="space-y-3">
          {mockHistory.map((h) =>
          <div
            key={h.id}
            className="bg-[#1a1a1a] border border-[#2a2a2a] rounded-2xl p-4 flex justify-between items-center">
            
              <div>
                <p className="font-medium text-white">{h.to}</p>
                <p className="text-xs text-[#a0a0a0]">{h.date}</p>
              </div>
              <p className="font-bold text-[#d4af37]">€{h.price.toFixed(2)}</p>
            </div>
          )}
        </div>
      </div>
    </div>);

}