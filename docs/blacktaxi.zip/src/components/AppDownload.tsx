import React from 'react';
import { Crown, Apple, Play } from 'lucide-react';
export function AppDownload({ onBook }: {onBook: () => void;}) {
  return (
    <section className="relative z-10 py-16 md:py-24 px-6 md:px-8">
      <div className="max-w-4xl mx-auto glass-panel p-8 md:p-16 text-center gold-glow">
        <Crown className="text-[#D4AF37] w-12 h-12 md:w-16 md:h-16 mx-auto mb-6 md:mb-8 animate-gold-shimmer" />
        <h2 className="font-serif text-3xl md:text-5xl tracking-[0.2em] text-[#D4AF37] font-light mb-4">
          ANIME TAXI
        </h2>
        <p className="font-sans text-[9px] md:text-[11px] uppercase tracking-[0.4em] text-white/60 mb-6 md:mb-8">
          EXECUTIVE TRANSPORT, ELEVATED.
        </p>

        <p className="text-xs md:text-sm text-white/40 mb-10 md:mb-12 max-w-md mx-auto leading-relaxed">
          Download the app and experience the finest rides in 2027.
        </p>

        <div className="flex flex-col sm:flex-row items-center justify-center gap-4 md:gap-6 mb-10 md:mb-12">
          <button className="w-full sm:w-auto flex items-center gap-4 px-8 py-4 border border-[#D4AF37] rounded-xl hover:bg-[#D4AF37]/10 transition-all group">
            <Apple className="w-5 h-5 md:w-6 md:h-6 text-white group-hover:text-[#D4AF37]" />
            <div className="text-left">
              <div className="text-[9px] md:text-[10px] uppercase tracking-widest text-white/40">
                Download on the
              </div>
              <div className="text-xs md:text-sm font-bold text-white">
                App Store
              </div>
            </div>
          </button>

          <button className="w-full sm:w-auto flex items-center gap-4 px-8 py-4 border border-[#D4AF37] rounded-xl hover:bg-[#D4AF37]/10 transition-all group">
            <Play className="w-5 h-5 md:w-6 md:h-6 text-white group-hover:text-[#D4AF37]" />
            <div className="text-left">
              <div className="text-[9px] md:text-[10px] uppercase tracking-widest text-white/40">
                Get it on
              </div>
              <div className="text-xs md:text-sm font-bold text-white">
                Google Play
              </div>
            </div>
          </button>
        </div>

        <button
          onClick={onBook}
          className="w-full sm:w-auto px-12 py-4 md:py-5 bg-[#D4AF37] text-black font-sans text-[11px] md:text-xs uppercase tracking-[0.2em] font-bold hover:bg-[#FFD700] transition-all gold-glow">
          
          Book Now in Browser
        </button>
      </div>
    </section>);

}