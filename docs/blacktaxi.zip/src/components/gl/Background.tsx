import React, { useEffect, useRef } from 'react';
import * as THREE from 'three';
export function Background() {
  const containerRef = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;
    // Scene setup
    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x000000);
    const camera = new THREE.PerspectiveCamera(
      75,
      container.clientWidth / container.clientHeight,
      0.1,
      1000
    );
    camera.position.z = 3;
    const renderer = new THREE.WebGLRenderer({
      antialias: true,
      alpha: true
    });
    renderer.setSize(container.clientWidth, container.clientHeight);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    container.appendChild(renderer.domElement);
    // Particle geometry
    const particlesCount = 3500;
    const positions = new Float32Array(particlesCount * 3);
    const scales = new Float32Array(particlesCount);
    for (let i = 0; i < particlesCount; i++) {
      positions[i * 3] = (Math.random() - 0.5) * 10;
      positions[i * 3 + 1] = (Math.random() - 0.5) * 10;
      positions[i * 3 + 2] = (Math.random() - 0.5) * 10;
      scales[i] = Math.random();
    }
    const geometry = new THREE.BufferGeometry();
    geometry.setAttribute('position', new THREE.BufferAttribute(positions, 3));
    geometry.setAttribute('aScale', new THREE.BufferAttribute(scales, 1));
    // Gold particle material
    const material = new THREE.PointsMaterial({
      color: new THREE.Color(0xd4af37),
      size: 0.018,
      sizeAttenuation: true,
      transparent: true,
      opacity: 0.9,
      depthWrite: false,
      blending: THREE.AdditiveBlending
    });
    const points = new THREE.Points(geometry, material);
    points.rotation.z = Math.PI / 4;
    scene.add(points);
    // Mouse interaction (introspect effect)
    const mouse = {
      x: 0,
      y: 0
    };
    const targetRotation = {
      x: 0,
      y: 0
    };
    const handleMouseMove = (e: MouseEvent) => {
      mouse.x = e.clientX / window.innerWidth * 2 - 1;
      mouse.y = -(e.clientY / window.innerHeight) * 2 + 1;
      targetRotation.x = mouse.y * 0.3;
      targetRotation.y = mouse.x * 0.3;
    };
    window.addEventListener('mousemove', handleMouseMove);
    // Animation loop
    const clock = new THREE.Clock();
    let frameId: number;
    const animate = () => {
      const elapsed = clock.getElapsedTime();
      points.rotation.y +=
      (targetRotation.y - points.rotation.y + elapsed * 0.0) * 0.02 + 0.0005;
      points.rotation.x += (targetRotation.x - points.rotation.x) * 0.02;
      renderer.render(scene, camera);
      frameId = requestAnimationFrame(animate);
    };
    animate();
    // Resize handler
    const handleResize = () => {
      if (!container) return;
      camera.aspect = container.clientWidth / container.clientHeight;
      camera.updateProjectionMatrix();
      renderer.setSize(container.clientWidth, container.clientHeight);
    };
    window.addEventListener('resize', handleResize);
    // Cleanup
    return () => {
      cancelAnimationFrame(frameId);
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('resize', handleResize);
      geometry.dispose();
      material.dispose();
      renderer.dispose();
      if (renderer.domElement.parentNode === container) {
        container.removeChild(renderer.domElement);
      }
    };
  }, []);
  return (
    <div
      ref={containerRef}
      className="fixed inset-0 z-0 bg-black"
      aria-hidden="true" />);


}