import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Background } from './components/gl/Background';
import { Header } from './components/Header';
import { Hero } from './components/Hero';
import { FeaturesStrip } from './components/FeaturesStrip';
import { HowItWorks } from './components/HowItWorks';
import { AppDownload } from './components/AppDownload';
import { Footer } from './components/Footer';
import { useScreenInit } from './useScreenInit';
import { BookingFlow } from './components/booking/BookingFlow';
export function App() {
  const screenInit = useScreenInit();
  const [isBooking, setIsBooking] = useState(screenInit.isBooking || false);
  return (
    <main className="relative bg-black min-h-screen">
      {/* Sacred GL Background - Fixed behind everything */}
      <Background />

      {/* UI Content - Scrolling over the GL */}
      <div className="relative z-10">
        <Header onBook={() => setIsBooking(true)} />

        <Hero onBook={() => setIsBooking(true)} />

        <div className="bg-gradient-to-b from-transparent via-black/40 to-black/60">
          <FeaturesStrip />

          <HowItWorks />

          <AppDownload onBook={() => setIsBooking(true)} />

          <Footer />
        </div>
      </div>

      {/* Booking Flow Overlay */}
      <AnimatePresence>
        {isBooking &&
        <motion.div
          initial={{
            opacity: 0,
            y: 100
          }}
          animate={{
            opacity: 1,
            y: 0
          }}
          exit={{
            opacity: 0,
            y: 100
          }}
          transition={{
            type: 'spring',
            damping: 25,
            stiffness: 200
          }}
          className="fixed inset-0 z-[100]">
          
            <BookingFlow onBackToLanding={() => setIsBooking(false)} />
          </motion.div>
        }
      </AnimatePresence>
    </main>);

}